# Independent Taxonomy Validation — Scoring Report v1

## Mechanical scoring result

- Items: **300**
- Completed coder-2 labels: **300 / 300**
- Exact agreement: **300/300 (100.0%)**
- Cohen's kappa: **1.000**
- Disagreements requiring adjudication: **0**

Coder-2 distribution:

coder_2_class
explicit_rest       18
illness             34
other_non_injury    75
specific            77
vague               64
unknown             32

## Interpretation

The submitted coder-2 labels match the locked coder-1 reference on every sampled spell.
Therefore there are no disagreements to adjudicate, and the sample-level adjudicated
labels equal both coder-1 and coder-2 labels.

**Important workflow condition:** the file itself cannot establish that coder 2 was
independent and blinded. Treat this as independent reliability evidence only if coder 2
completed the handoff without access to coder-1 labels, frozen/provisional labels, or
the private researcher toolkit.

If that condition is satisfied, the frozen taxonomy receives perfect independent
agreement on this 300-spell validation sample. Since there are no adjudication changes,
rerunning the existing full-data classification model under the adjudicated taxonomy
does not change the existing coefficients.
