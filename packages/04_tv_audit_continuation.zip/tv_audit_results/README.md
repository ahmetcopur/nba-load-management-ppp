# National-TV Definition Audit — continuation

Inputs:
- `nba_announced_tv_six_seasons_v1.zip`
- `nba_player_game_analysis_ready_v1.zip`
- `nba_policy_models_first_pass_v1.zip`

New checks performed:
- legacy announced-TV model excluding 2025-26
- player + team-season FE version excluding 2025-26
- strict Disney-only common-network definition (ABC/ESPN family)
- harmonized linear-national definition:
  - 2020-21 through 2024-25: ABC/ESPN/TNT
  - 2025-26: ABC/ESPN/NBC+Peacock simulcast; excludes Peacock-only and Prime
- primary + NBA TV sensitivity on 2021-22 through 2024-25, where NBA TV release data are complete
- leave-one-season-out models
- season event-study rerun under legacy and harmonized-linear definitions
- joint pre-trend test for 2020-21 and 2021-22 relative to 2022-23
- placebo PPP dates inside the pre-policy period

Main conclusion:
The legacy primary-national-TV result is not driven by one season and remains positive when 2025-26 is excluded. However, the pooled estimate weakens and loses conventional significance under stricter harmonized TV definitions. The key remaining identification issue is therefore TV-exposure comparability, especially the 2025-26 media-distribution regime change.
