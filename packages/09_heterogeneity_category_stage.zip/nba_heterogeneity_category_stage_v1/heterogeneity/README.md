# NBA PPP — Predeclared Heterogeneity v1

This package estimates whether the focal Star × PostPPP × TV difference-in-difference-in-differences varies across four predeclared, already-observed dimensions. The model retains player and team-season fixed effects and two-way player/game clustered inference.

## Frozen subgroup definitions

1. **Back-to-back:** current game is the second night of a back-to-back.
2. **Weak opponent:** pregame bottom-quartile opponent indicator.
3. **High recent workload:** prior-10-roster-game minutes >= the season-specific 75th percentile; estimation sample requires at least 10 prior roster games.
4. **65-game proximity:** among player-games 0-15 games short of 65, compare 0-5 short (H=1) with 6-15 short (H=0).
5. **Age/career stage:** intentionally not estimated in v1 because the frozen panel lacks a reliable age/experience field.

For each binary H, the regression includes the complete Star × PostPPP × TV × H factorial. `difference_h1_minus_h0_pp` is the formal four-way interaction. `heterogeneity_q_bh` applies Benjamini-Hochberg FDR correction across the four tests separately within each TV-definition family.

These are heterogeneity analyses, not replacements for the frozen main effect.
