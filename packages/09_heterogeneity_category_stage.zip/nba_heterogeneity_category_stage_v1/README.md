# NBA PPP — Heterogeneity + Adjusted Category Stage v1

This package closes two preplanned final-model tasks: predeclared heterogeneity and multiple-testing-adjusted category decomposition.

- `heterogeneity/`: four predeclared observed dimensions under legacy and harmonized TV, with formal four-way interaction tests and BH correction. Age/career stage remains pending because the frozen panel lacks reliable metadata.
- `category_fdr/`: vague, specific, explicit-rest, and other-absence onset models with BH and Holm adjustment within each TV-definition family.
- `explicit_rest_diagnostic/`: raw-cell diagnostic for the only adjusted category signal. It shows the positive explicit-rest DDD is a relative eight-cell contrast despite virtually zero direct explicit-rest events in star national-TV cells.
