# Category Decomposition with Multiple-Testing Adjustment — v1

The four category-specific onset outcomes (vague, specific, explicit rest, other absence) are fit using the standard player + team-season FE LPM with player/game two-way clustered inference. The focal coefficient is Star × PostPPP × TV. Benjamini-Hochberg FDR q-values and Holm-adjusted p-values are calculated separately across the four category tests within each TV-definition family.

The primary all-absence endpoint is not included in this family because it was pre-specified as the main extensive-margin outcome rather than one of several category discoveries.
