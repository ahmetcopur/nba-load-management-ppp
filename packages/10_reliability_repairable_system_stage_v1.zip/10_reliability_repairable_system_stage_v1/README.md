# Stage 10 Reliability / Repairable-System Extension

This package contains the frozen Stage-10 extension of the NBA Player
Participation Policy analysis.

## Purpose

Stage 10 treats player availability as a two-state repairable process:

Available -> Absent = new absence onset
Absent -> Available = return / repair

It studies repair hazards, short absence spells, and transition timing around
advance-announced national-TV games.

Stages 1-9 are unchanged.

## Reproduction order

From the root of the full repository:

1. python scripts/portable/build_reliability_stage10_panels.py
2. python scripts/portable/run_reliability_stage10_repair.py
3. python scripts/portable/run_reliability_stage10_category_contrast.py
4. python scripts/portable/run_reliability_stage10_short_spells.py
5. python scripts/portable/run_reliability_stage10_event_time.py
6. python scripts/portable/run_reliability_stage10_event_sensitivities.py

## Large derived data

The generated directory:

data_intermediate/reliability_stage10/

is intentionally not included in this archive or tracked in Git because it is
approximately 40 MB and is deterministically reconstructed by the Stage-10
builder.

SHA-256 hashes of the frozen generated files are included in:

manifests/DERIVED_STAGE10_SHA256.txt

Hashes of the required upstream frozen inputs are included in:

manifests/UPSTREAM_INPUT_SHA256.txt

## Interpretation

The reliability extension does not establish strategic or disguised
load-management behavior. The frozen interpretation is provided in
documentation/RELIABILITY_STAGE10_RESULTS.md.
