# Nonlinear + Multinomial Robustness v1

This stage is a functional-form robustness check after the identification/falsification and taxonomy-reproducibility stages. Inferential claims remain anchored to the already-frozen two-way-clustered LPM.

## Binary nonlinear model
Sparse logistic regression with player and team-season indicators, all lower-order Star/PostPPP/TV terms, and the same pregame controls. `C=10` is the primary weak-ridge stabilization.

### New absence onset
- Legacy TV: nonlinear average DDD **2.44 pp**, focal interaction OR **1.47**.
- Harmonized TV: nonlinear average DDD **0.83 pp**, focal interaction OR **1.10**.

The frozen latest-pre-tip LPM estimates were +3.15 pp and +1.77 pp respectively; cadence-harmonized LPM estimates were +2.63 pp and +1.24 pp. Nonlinearity therefore does not remove the exposure-measurement sensitivity.

### Vague vs specific, conditional on injury onset
- Legacy TV: nonlinear average DDD **-5.42 pp**, OR **0.74**.
- Harmonized TV: nonlinear average DDD **-4.43 pp**, OR **0.78**.

The sign remains negative. The nonlinear model therefore provides no support for an increase in vague rather than specific labeling in the focal policy cell.

## Five-state multinomial competing-risk diagnostic
States: plays, specific injury onset, vague injury onset, explicit rest onset, other absence onset. Player and team-season indicators and the same covariates are used; `C=1` stabilizes sparse categories. These are point-estimate diagnostics, not new significance tests.

Legacy-TV DDD (pp): plays -1.84; specific 0.39; vague 0.38; rest 0.39; other 0.68.

Harmonized-TV DDD (pp): plays -0.93; specific 0.15; vague 0.15; rest 0.41; other 0.22.

The category effects sum to approximately zero by construction. There is no clean multinomial pattern in which the post-PPP star/TV differential shifts specifically into vague injury wording.

## Freeze decision
**Functional-form robustness is complete.** The nonlinear results preserve the same substantive conclusion: a positive availability pattern under the legacy TV definition, materially weaker under harmonized exposure measurement, and no supported vague-label mechanism.

## Next stage
Freeze a small set of heterogeneity hypotheses before looking at coefficients: back-to-back status, weak opponents, workload, age/career stage, and distance to the 65-game threshold. Avoid broad subgroup fishing.
