# Model specification

## Primary interaction

`Star × PostPPP × announced_tv_primary`

All constituent lower-order terms are included. The PostPPP main effect is
absorbed by season fixed effects.

## Extensive-margin baseline

Outcome: `absence_onset`

Estimator: linear probability model after iterative absorption of player and
season fixed effects.

Inference: two-way cluster-robust covariance by player and game.

Controls:

- home
- back-to-back
- three games in four days
- four games in six days
- travel since previous game
- absolute timezone shift
- road-trip game number
- pregame signed Elo advantage
- bottom-quartile opponent
- opponent back-to-back
- rest advantage
- travel disadvantage
- NBA Cup game
- minutes in prior 10 roster games
- games played before the game
- distance to the 65-game threshold

A stronger robustness model absorbs player and team-season fixed effects.

## Classification margin

The sample is restricted to new injury onsets whose frozen classification is
either `vague` or `specific`. The binary outcome equals one for a vague label.

## Event study

The star-by-announced-TV differential is interacted separately with season,
using 2022-23 as the reference season. The plotted estimates are relative to
the 2022-23 star-by-TV differential.

## Important interpretation

These are observational difference-in-difference-in-differences estimates.
They are not automatically causal. The identifying interpretation requires
parallel differential trends and no post-policy shock that differentially
changes star availability in announced-TV games relative to the comparison
cells.
