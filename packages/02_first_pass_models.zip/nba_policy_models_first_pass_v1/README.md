# NBA Disguised Load Management — First-Pass Policy Models

This is the first coefficient-reading package from the frozen analysis-ready
panel. It should not yet be treated as the final paper result.

## Main finding

The baseline extensive-margin interaction is:

- **3.41 percentage points**
- 95% CI: **[0.86, 5.96]**
- p = **0.0087**

The stronger player + team-season fixed-effect model is:

- **3.15 percentage points**
- 95% CI: **[0.57, 5.73]**
- p = **0.0167**

Thus, in this first-pass specification, new absence onsets increased
differentially for stars in preseason-announced national-TV games after the PPP.

## Classification finding

Conditional on a new injury-labelled onset, the vague-versus-specific
interaction is:

- **-8.42 percentage points**
- 95% CI: **[-23.96, 7.12]**
- p = **0.2884**

This does not support a detectable shift from specific to vague injury wording
in the focal cell.

## Category decomposition

- Vague injury onset: 1.60 pp, p = 0.0704
- Specific injury onset: 0.75 pp
- Explicit-rest onset: 0.63 pp, p = 0.0111
- Other absence onset: 0.43 pp

The explicit-rest estimate is exploratory because rest onsets are sparse.

## Robustness pattern

The extensive-margin estimate remains positive when:

- 2020-21 is excluded
- Cup games are excluded
- opening-night star status is used
- the covariate set is removed
- team-season fixed effects are added

It becomes smaller and only marginally precise when NBA TV is added to the
national-TV definition.

## Event-study pattern

Relative to 2022-23, the pre-period interactions for 2020-21 and 2021-22 are
not statistically distinguishable from zero. Post-period estimates increase
from 2023-24 through 2025-26, with 2025-26 individually positive at the 5%
level.

## Limits before a final claim

- Observational design; parallel differential trends remain an assumption.
- The taxonomy review was assistant-coded, not independent human double-coding.
- Age and experience controls are not yet included.
- The explicit-rest model is sparse.
- A nonlinear fixed-effect robustness model has not yet been added.
- Multiple-testing adjustments have not yet been applied to exploratory
  category decompositions.

## Files

- `focal_triple_interaction_results.csv`
- `category_models_focal.csv`
- `teamseason_fe_focal.csv`
- `season_event_study_absence.csv`
- `raw_policy_cells.csv`
- `all_model_coefficients.csv`
- `figures/`
- `scripts/`
