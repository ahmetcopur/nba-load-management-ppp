# Cadence robustness rebuild plan

A true cadence robustness panel must be generated upstream of the regression.

1. Use each season's canonical `game_snapshot_join_harmonized` selection based on the common 1:30, 5:30 and 8:30 ET checkpoints.
2. Recover/parse the selected harmonized PDF rows.
3. Apply the frozen season-team-name -> NBA player-ID crosswalk.
4. Rebuild team-game submission usability from the harmonized snapshots.
5. Merge the same official boxscore roster denominator and game covariates.
6. Recompute `absence_now`, spells, left censoring, `at_risk_for_new_onset`, and `absence_onset`.
7. Apply the frozen v2 wording taxonomy to harmonized report reasons.
8. Merge the already frozen star, Cup and TV definitions.
9. Run the same player + team-season FE model and the harmonized-TV specification.
10. Compare row loss, onset counts, and the DDD estimate against the canonical latest-pre-tip panel.

Do not simply replace report timestamps in the final panel: the designation and risk-set variables are downstream of snapshot selection.
