# NBA Load Management — Identification & Falsification Stage 2 v1

This package continues the first-pass DDD model after the national-TV definition audit.
The focal estimand remains `Star × PostPPP × AnnouncedTV` for new absence onset.

## Standard specification

Player + team-season fixed effects, full pregame controls, and two-way clustering by player and game are treated as the standard model for this stage.

### Legacy announced-national-TV definition
- Estimate: +3.149 pp
- 95% CI: [+0.571, +5.728]
- p = 0.0167

### Harmonized linear-national definition
- Estimate: +1.775 pp
- 95% CI: [-0.800, +4.349]
- p = 0.1766

The harmonized definition is intentionally stricter across the 2025-26 media-rights regime change.

## Player-specific linear trends

Sparse exact absorption of:
- player intercepts,
- player-specific linear calendar-time slopes,
- team-season fixed effects.

Legacy TV: +3.258 pp, p = 0.0136.
Harmonized TV: +2.151 pp, p = 0.1034.

Thus player-specific linear availability trends do not explain the legacy result, but the harmonized-TV estimate remains imprecise.

## Clustering sensitivity

For the legacy TV definition, the point estimate is unchanged (+3.149 pp) and remains below p=.05 under:
- player clustering,
- game clustering,
- team clustering (30 clusters, t reference),
- date clustering,
- player + game two-way clustering,
- team + date two-way clustering (conservative 29 df reference).

For the harmonized definition, none of these clustering choices yields conventional significance.

## COVID-era sensitivity

Removing both 2020-21 and 2021-22:
- Legacy TV: +3.839 pp, p = 0.0205.
- Harmonized TV: +2.414 pp, p = 0.1624.

A separate COVID dummy is not meaningful in the standard model because team-season fixed effects absorb season-wide shocks.

## Stratified TV-exposure permutation placebo

99 game-level permutations were performed for each TV definition, shuffling TV status within `season × calendar month` while preserving the exact number of TV games in every stratum. Fixed effects and the full nuisance-control set are removed using FWL residualization before calculating the focal coefficient.

- Legacy: observed +3.153 pp; two-sided permutation-style p = 0.09; upper-tail p = 0.06.
- Harmonized: observed +1.779 pp; two-sided p = 0.26; upper-tail p = 0.13.

**Important:** national-TV assignment is observational, not randomized. These are randomization-style falsification/reference p-values, not exact Fisher randomization-inference p-values. The legacy result therefore survives conventional clustered inference but is not unusually extreme at the 5% level under this particular shuffled-TV reference distribution.

## Relation to the prior TV-audit package

The `prior_tv_audit/` directory includes:
- leave-one-season-out results,
- the legacy-vs-harmonized event study,
- the joint pretrend test,
- pre-period fake-policy dates,
- TV source counts and TV-definition models.

## Cadence-harmonized injury-report sensitivity

The season-level harmonized snapshot selections do exist (common 1:30/5:30/8:30 ET checkpoints). However, the frozen analysis-ready panel stores outcomes constructed from the canonical latest-pre-tip report. A valid cadence test therefore requires rebuilding selected player-report rows, designation classes, absence spells, and the onset risk set from the harmonized snapshots. Merely changing a regression column in the current panel would not be a genuine cadence robustness test.

The harmonized selector artifacts have been located, so this is a reconstruction task rather than a data-availability problem.

## Current interpretation

The legacy exposure result is robust to player trends, clustering choices, pandemic-season exclusion, leave-one-season-out checks, and fake pre-policy dates. But the coefficient is materially weaker under harmonized TV exposure and does not pass the 5% threshold in the stratified shuffled-TV placebo. The evidence is therefore still exposure-definition-sensitive and should not yet be presented as a definitive causal PPP effect.
