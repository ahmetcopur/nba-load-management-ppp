# Six-Season Announced National-TV Panel

This combines the corrected 2020-21 two-segment reconstruction with the
validated 2021-22 through 2025-26 preseason-PDF reconstruction.

## Main variable

Use `announced_tv_primary`.

- 2020-21 through 2024-25: ABC, ESPN and TNT.
- 2025-26: ABC/ESPN, NBC/Peacock, Peacock and Prime.

## Important exceptions

- 2020-21 final-week ESPN/TNT windows had unspecified matchups at the
  second-half release. Eventual flex selections remain zero for
  matchup-announced treatment.
- NBA TV is a separate sensitivity variable. Its complete second-half
  schedule could not be recovered for 2020-21, so those values are missing.
- In 2023-24, 2024-25 and 2025-26, 30 Cup-determined games per season were
  not known at the initial schedule release and are explicitly flagged.
