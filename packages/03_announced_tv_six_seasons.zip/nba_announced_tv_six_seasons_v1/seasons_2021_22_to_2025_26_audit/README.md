# NBA Preseason-Announced National TV - Validated v2

This package supersedes `announced_tv_v1`.

## Main correction

The original extractor parsed only rows with a network label. It therefore
could not distinguish:

1. a game listed in the preseason schedule with no national network; and
2. a matchup that was genuinely unknown/TBD at schedule release.

v2 parses every game row in the original NBA schedule PDFs and performs a
one-to-one ordered home/away join to the realized fixture file. Announced
network status follows a game through later postponements or rescheduling.

## Coverage

- 2021-22 and 2022-23: 1,230 of 1,230 games listed at release.
- 2023-24, 2024-25 and 2025-26: 1,200 games listed at release and 30
  Cup-determined games not yet defined, per season.
- Total: 6,060 listed schedule rows plus 90 post-release Cup-determined games.

## Primary coding

Through 2024-25:
- Primary national: ABC, ABC/ESPN, ESPN, TNT
- NBA TV: separate sensitivity flag

For 2025-26:
- Primary national: ABC, ABC/ESPN, ESPN, NBC/Peacock, Peacock, Prime
- NBA TV was not included in the initial release PDF.

## Recommended fields

- `listed_at_release`
- `network_announced`
- `announced_tv_primary`
- `announced_nba_tv`
- `announced_tv_status`
- `mapping_method`
- `schedule_date_shift_days`

Games with `matchup_tbd_at_schedule_release` must not be coded as ordinary
non-national games in the main announced-TV analysis.

2020-21 remains pending because the schedule was released in two halves.
