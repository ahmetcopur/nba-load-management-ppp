# 2020-21 Announced National-TV Reconstruction v2

This package supersedes the uploaded v1 output.

## Corrected parser issue

The WBD tables place the date in the second column, while the original parser
looked only at the first column. That caused all TNT and first-half NBA TV rows
to be missed. The ESPN Christmas table also needed an explicit December 25
date because its first column contains tip time rather than date.

## Validated primary treatment

`announced_tv_primary` is complete for matchup-specified ABC, ESPN and TNT
announcements across both schedule segments:

- ESPN/ABC first half: 49 source rows
- ESPN/ABC second half: 46 matchup-specified rows
- TNT first half: 36 source rows
- TNT second half: 27 matchup-specified rows
- Unique played games coded primary national: 156

The final week contained four TNT and five ESPN slots with matchups still TBD
at the second-half release. Eventual flex selections are not retroactively
coded as matchup-announced.

## NBA TV limitation

The first-half NBA TV table is complete (61 games). The archived second-half
NBA TV press page contains only selected highlights and points to a historical
NBA.com schedule that is no longer exposed as a complete static list.
Therefore `announced_nba_tv` is missing, not zero, for second-half games.

Use `announced_tv_primary` for the main model. Do not run a full-season
2020-21 NBA TV sensitivity analysis from this file.
